
def sum_two_numbers(a, b):
    return a + b
