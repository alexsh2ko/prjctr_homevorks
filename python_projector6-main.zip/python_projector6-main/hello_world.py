print('Hello World1')


print('Next one')

4 + 6