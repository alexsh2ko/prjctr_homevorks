# from module import function_name
from utils import add, square

result2 = add(2, 2)
print(result2)
result3 = square(2)
print(result3)

# -----------------------------

# # from module import function_name as alias
# from utils import (
#     add as sum_two_numbers,
#     square as multiply_two_numbers,
# )

# result3 = sum_two_numbers(2, 2)
# print(result3)

# result4 = multiply_two_numbers(3)
# print(result4)

# -----------------------------

# import random

# value = random.randint(1, 10)
# print(value)

# -----------------------------

# from random import randint

# sorted_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# print(randint(0, 3))

# -----------------------------

# from datetime import datetime

# print(datetime.now().date())

# -----------------------------

# import datetime as dt

# print(dt.datetime.now())

# -----------------------------
