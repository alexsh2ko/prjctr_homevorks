def add(x, y):
    return x + y


def square(x):
    return x * x
